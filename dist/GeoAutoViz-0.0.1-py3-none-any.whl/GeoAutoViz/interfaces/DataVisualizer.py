from abc import ABC, abstractmethod


class DataVisualizer(ABC):
    #ß@abstractmethod
    def visualize_data(self):
        pass
