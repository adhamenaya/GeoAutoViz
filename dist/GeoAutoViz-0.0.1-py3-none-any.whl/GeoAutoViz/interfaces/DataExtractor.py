from abc import abstractmethod
class DataExtractor:
    @abstractmethod
    def extract(self):
        pass