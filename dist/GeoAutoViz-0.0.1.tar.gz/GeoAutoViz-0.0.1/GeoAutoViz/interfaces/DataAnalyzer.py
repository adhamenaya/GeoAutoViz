from abc import ABC, abstractmethod


class DataAnalyzer(ABC):
    #ß@abstractmethod
    def analyze_data(self):
        pass
